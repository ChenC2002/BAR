# CKD Demo Results

One trained run (seed 7) under the MIMIC-III demo configuration.
BAR and its frozen Stage-1 EHR baseline are evaluated at 30, 90 and 365 days.
The three horizons are tasks within one run, not three independent runs.

- `per_run.csv`: test AUROC, average precision (AP), Brier score and cohort counts.
- `macro.csv`: unweighted mean of each metric across the three horizons.
- `runs/seed-7/evaluation.json`: the actual checkpoint re-evaluation report.
- `bar-demo-model.zip`: trained weights, frozen EHR baseline, router, evidence graph, uncertainty distributions, fitted preprocessing and configuration.
- `manifest.json`: SHA-256 checksums of the attachment files.

Metrics are fractions, not percentages. AP is computed with scikit-learn's average_precision_score. `ehr` denotes the frozen EHR baseline.

## Recompute

From a BAR repository checkout, with authorized MIMIC-III data and the original ICD9CM-to-UMLS mapping, run (substitute the extracted attachment path):

```bash
python -m pip install ".[experiment]"
python scripts/evaluate_mimic_demo.py \
  --bundle /path/to/bar-ckd-results/bar-demo-model.zip \
  --data /path/to/MIMICIII/data \
  --mapping /path/to/KG_mapping/ICD9CM_to_UMLS.csv \
  --out artifacts/ckd-evaluation.json
python scripts/package_ckd_results.py \
  --report artifacts/ckd-evaluation.json \
  --bundle /path/to/bar-ckd-results/bar-demo-model.zip \
  --out artifacts/bar-ckd-results.zip
```

No retraining or LLM API is required. Evaluation metrics must match the release within 1e-6; elapsed time varies by machine.
