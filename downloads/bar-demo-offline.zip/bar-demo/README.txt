BAR Evidence Explorer
Open index.html in a browser. No server or installation is required.
