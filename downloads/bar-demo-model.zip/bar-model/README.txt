BAR CKD demo inference bundle

bar.pt: trained BAR, frozen EHR baseline, query router, evidence graph and uncertainty CDFs.
features.json: fitted vocabulary, imputation, missingness indicators and scaling.
config.json: recorded run configuration.
public_demo.json: example inputs, recorded outputs and aggregate metrics.

From a BAR repository checkout:
python -m pip install .
python scripts/predict_demo.py --bundle downloads/bar-demo-model.zip --verify-all

Evaluate the full Experiment on the authorized MIMIC-III data host, without training:
python -m pip install ".[experiment]"
python scripts/evaluate_mimic_demo.py --data /path/to/MIMICIII/data --mapping /path/to/KG_mapping/ICD9CM_to_UMLS.csv --out artifacts/ckd-evaluation.json
The report recomputes aggregate metrics and checks them against this release.

The JSON preprocessor does not require loading joblib or pickle objects.
Load checkpoint tensors with torch.load(weights_only=True).
Reference runtime: Python 3.11, PyTorch 2.15.0, NumPy 2.5.4.
Research use; these scores are not clinical recommendations.
UMLS content remains subject to its source license terms:
https://www.nlm.nih.gov/research/umls/faq_main.html
